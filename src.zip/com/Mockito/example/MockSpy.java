package com.Mockito.example;

public enum MockSpy {

}
