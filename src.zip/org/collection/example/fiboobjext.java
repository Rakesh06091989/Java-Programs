package org.collection.example;

public class fiboobjext extends Object{
	
	public static void main(String []args)
	{
		System.out.println("welcome to the meera's world");
	}

}
