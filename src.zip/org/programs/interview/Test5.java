package org.programs.interview;

public class Test5{ 
	
	  static void m(Object i){System.out.println("Object");}  
	  //static void m(Integer i){System.out.println("Integer");}  
	  static void m(String i){System.out.println("String");} 
	  public static void main(String args[]){  
	   m(null);  
	 }   
	}  
