package org.programs.interview;

import java.util.Scanner;

public class Test21 {

 
	public static void main(String[] args) {
	
		int a =97;
		String s = "a";
		if(s.equals(a))
		{
			System.out.println("selected");
		}
		else
		{
			System.out.println("go to hell");
		}
		
	}

}
