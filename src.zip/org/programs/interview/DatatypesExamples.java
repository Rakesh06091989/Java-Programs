package org.programs.interview;

public class DatatypesExamples {

	public static void main(String[] args) {
		
		Integer abc = null;
		//int a = abc;//it will give you null pointer exception.
		
		Integer int1 = new Integer(45);
		int1 += 50;
		System.out.println(int1);

	}

}
