package org.programs.interview;

public class Test20 {

	static {
		System.out.println("program without main method");
		System.exit(0);
	}
}
