package org.programs.interview;

public class Test {

	public static void main(String[] args) {
		
		String [] args1 = {"abc","xyz"};

		main(args1[0]);
	}

	public static void main(String args) {
	
		System.out.println(args);
	}
}
