package org.abstraction.example;

import java.util.concurrent.ConcurrentHashMap;

public class Hero extends Bike{

	public Hero() {
		super();
	}

	public static void main(String[] args) {
		Hero hero = new Hero();
		ConcurrentHashMap<String, Integer> map= new ConcurrentHashMap<>();

	}

	@Override
	void run() {
		// TODO Auto-generated method stub
		
	}

}
