package org.abstraction.example;

public interface Shape {
	
	void draw();
	void print();

}
