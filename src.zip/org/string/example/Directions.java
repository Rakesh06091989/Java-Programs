package org.string.example;

public enum Directions {

	EAST, 
	  WEST, 
	  NORTH, 
	  SOUTH

}
