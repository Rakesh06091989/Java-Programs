package org.method.overing.overloading;

public interface shape1 {
	
	int A = 25;
	public void draw();

}
