package org.method.overing.overloading;

public interface shape {
	
	int A = 15;
	public void draw();

}
